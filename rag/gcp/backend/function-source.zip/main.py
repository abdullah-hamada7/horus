import os
import json
import functions_framework
from google.cloud import discoveryengine_v1 as discoveryengine

@functions_framework.http
def query_kb(request):
    # Set CORS headers for preflight requests
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    # Set CORS headers for the main request
    headers = {
        'Access-Control-Allow-Origin': '*'
    }

    try:
        request_json = request.get_json(silent=True)
        query = request_json.get('query') if request_json else None

        if not query:
            return (json.dumps({'error': 'No query provided'}), 400, headers)

        project_id = os.environ.get('PROJECT_ID')
        location = os.environ.get('LOCATION_ID', 'global')
        datastore_id = os.environ.get('DATASTORE_ID')

        client = discoveryengine.SearchServiceClient()

        serving_config = client.serving_config_path(
            project=project_id,
            location=location,
            data_store=datastore_id,
            serving_config="default_config",
        )

        search_request = discoveryengine.SearchRequest(
            serving_config=serving_config,
            query=query,
            page_size=5,
            content_search_spec={
                "summary_spec": {
                    "summary_result_count": 5,
                    "include_citations": True,
                    "model_spec": {"version": "stable"},
                }
            },
        )

        response = client.search(search_request)

        # Extract answer from summary
        answer = response.summary.summary_text if response.summary else "I couldn't find an answer to your question."
        
        # Extract sources
        sources = []
        for result in response.results:
            doc = result.document
            # Handle source metadata mapping based on Vertex AI Search results
            source_link = doc.derived_struct_data.get('link', 'N/A')
            sources.append({
                'title': doc.derived_struct_data.get('title', 'Document'),
                'snippet': doc.derived_struct_data.get('snippets', [{'snippet': ''}])[0].get('snippet', ''),
                'link': source_link
            })

        return (json.dumps({
            'answer': answer,
            'sources': sources
        }), 200, headers)

    except Exception as e:
        print(f"Error: {e}")
        return (json.dumps({'error': str(e)}), 500, headers)
